package com.gyankasamandar

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import android.content.Context
import androidx.core.content.ContextCompat

private data class Gyan(val title: String, val text: String)
private data class Poster(val title: String, val resId: Int)

class MainActivity : ComponentActivity() {
    private val notificationPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) scheduleDailyNotification(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createNotificationChannel(this)
        scheduleDailyNotification(this)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
        setContent { GyanApp() }
    }
}

@Composable
fun GyanApp() {
    val gyans = listOf(
        Gyan("आज की ज्ञान की बात", "ज्ञान जिंदगी को दिशा देता है, और समय उसे मंज़िल तक पहुँचाता है।"),
        Gyan("समय की कदर", "समय सबसे बड़ा शिक्षक है—जो समय को समझता है, वह जीवन को समझता है।"),
        Gyan("सच्ची सफलता", "सफलता सिर्फ मंज़िल नहीं, बल्कि हर दिन कुछ नया सीखने का नाम है।"),
        Gyan("अच्छी सोच", "मुश्किल रास्ते अक्सर खूबसूरत मंज़िल तक ले जाते हैं।")
    )
    val posters = listOf(
        Poster("ज्ञान और समय", R.drawable.poster_gyaan),
        Poster("समय और सम्मान", R.drawable.poster_samay),
        Poster("समय की सीख", R.drawable.poster_samman)
    )
    var tab by remember { mutableIntStateOf(0) }
    val favorites = remember { mutableStateListOf<String>() }
    var showOnlyFavorites by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFFFC107), background = Color(0xFF101010), surface = Color(0xFF1B1B1B))) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("GYAN KA SAMANDAR", fontWeight = FontWeight.ExtraBold) },
                    actions = {
                        IconButton(onClick = { showOnlyFavorites = !showOnlyFavorites }) {
                            Icon(if (showOnlyFavorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "पसंदीदा")
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(containerColor = Color(0xFF151515), titleContentColor = Color(0xFFFFC107))
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF151515)) {
                    NavigationBarItem(tab == 0, { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("होम") })
                    NavigationBarItem(tab == 1, { tab = 1 }, icon = { Icon(Icons.Default.Star, null) }, label = { Text("ज्ञान") })
                    NavigationBarItem(tab == 2, { tab = 2 }, icon = { Icon(Icons.Default.Notifications, null) }, label = { Text("रिमाइंडर") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(gyans, favorites, showOnlyFavorites, Modifier.padding(padding))
                1 -> PosterScreen(posters, Modifier.padding(padding))
                else -> ReminderScreen(Modifier.padding(padding))
            }
        }
    }
}

@Composable
private fun HomeScreen(gyans: List<Gyan>, favorites: MutableList<String>, onlyFav: Boolean, modifier: Modifier) {
    val visible = if (onlyFav) gyans.filter { favorites.contains(it.text) } else gyans
    LazyColumn(modifier.fillMaxSize().background(Color(0xFF101010)).padding(horizontal = 16.dp), contentPadding = PaddingValues(vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("हर दिन एक नई सीख 🌊", color = Color.LightGray, fontSize = 15.sp)
            Spacer(Modifier.height(8.dp))
        }
        items(visible) { g ->
            val fav = favorites.contains(g.text)
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1D1D1D)), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text(g.title, color = Color(0xFFFFC107), fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(g.text, color = Color.White, fontSize = 18.sp, lineHeight = 27.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        IconButton(onClick = { if (fav) favorites.remove(g.text) else favorites.add(g.text) }) {
                            Icon(if (fav) Icons.Default.Favorite else Icons.Default.FavoriteBorder, "पसंद", tint = Color(0xFFFFC107))
                        }
                        IconButton(onClick = { shareText(LocalContextHolder.current, g.text) }) { Icon(Icons.Default.Share, "शेयर") }
                    }
                }
            }
        }
        if (visible.isEmpty()) item { Text("अभी कोई पसंदीदा ज्ञान नहीं है।", color = Color.Gray, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center) }
    }
}

@Composable
private fun PosterScreen(posters: List<Poster>, modifier: Modifier) {
    LazyColumn(modifier.fillMaxSize().background(Color(0xFF101010)), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item { Text("HD पोस्टर", color = Color(0xFFFFC107), fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        itemsIndexed(posters) { _, poster ->
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF1B1B1B))) {
                Column {
                    Image(painterResource(poster.resId), contentDescription = poster.title, modifier = Modifier.fillMaxWidth().height(430.dp), contentScale = ContentScale.Crop)
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(poster.title, color = Color.White, modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold)
                        IconButton(onClick = { shareText(LocalContextHolder.current, "GYAN KA SAMANDAR — ${poster.title}") }) { Icon(Icons.Default.Share, "शेयर") }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReminderScreen(modifier: Modifier) {
    Column(modifier.fillMaxSize().background(Color(0xFF101010)).padding(22.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("रोज़ का ज्ञान रिमाइंडर 🔔", color = Color(0xFFFFC107), fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("ऐप रोज़ सुबह लगभग 9:00 बजे एक ज्ञान की बात का notification भेजने की कोशिश करेगा।", color = Color.White, fontSize = 17.sp, lineHeight = 25.sp)
        Button(onClick = { scheduleDailyNotification(LocalContextHolder.current) }, modifier = Modifier.fillMaxWidth()) { Text("रिमाइंडर चालू करें") }
    }
}

@Composable
private object LocalContextHolder {
    @Composable get() = androidx.compose.ui.platform.LocalContext.current
}

private fun shareText(context: Context, text: String) {
    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_TEXT, text + "\n\nGYAN KA SAMANDAR 🌊")
    }
    context.startActivity(Intent.createChooser(intent, "शेयर करें"))
}

private fun createNotificationChannel(context: Context) {
    if (android.os.Build.VERSION.SDK_INT >= 26) {
        val channel = android.app.NotificationChannel("gyan_daily", "Daily Gyan", android.app.NotificationManager.IMPORTANCE_DEFAULT)
        context.getSystemService(android.app.NotificationManager::class.java).createNotificationChannel(channel)
    }
}

private fun scheduleDailyNotification(context: Context) {
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    val intent = Intent(context, DailyNotificationReceiver::class.java)
    val pending = PendingIntent.getBroadcast(context, 1001, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    val now = java.util.Calendar.getInstance().apply { set(java.util.Calendar.HOUR_OF_DAY, 9); set(java.util.Calendar.MINUTE, 0); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0) }
    if (now.timeInMillis <= System.currentTimeMillis()) now.add(java.util.Calendar.DAY_OF_YEAR, 1)
    alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, now.timeInMillis, AlarmManager.INTERVAL_DAY, pending)
}
