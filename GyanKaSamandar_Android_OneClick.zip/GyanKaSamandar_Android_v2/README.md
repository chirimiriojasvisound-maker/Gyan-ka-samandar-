# GYAN KA SAMANDAR — Phone Build Edition

This Android project includes a GitHub Actions workflow that builds a debug APK in the cloud.

## Phone-only build
1. Create/sign in to GitHub.
2. Create a new repository.
3. Upload all files from this project to the repository.
4. Open **Actions** → **Build GYAN KA SAMANDAR APK** → **Run workflow**.
5. When it finishes, open the successful workflow run and download the **GyanKaSamandar-debug-apk** artifact.

The workflow uses a GitHub-hosted runner to build the Android app with Gradle and uploads the APK as an artifact.
